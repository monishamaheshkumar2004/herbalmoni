package com.example.herbalhub

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
